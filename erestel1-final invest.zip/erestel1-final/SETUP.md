# Erestel1 — Netlify Environment Variable Setup

## Add the API Key to Netlify (ONE TIME ONLY)

1. Go to: app.netlify.com/projects/1intelligence/settings/env-vars
2. Click "Add a variable"
3. Key: ANTHROPIC_API_KEY
4. Value: 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
5. Click Save

## Done!
The AI Partner will work automatically after this.
